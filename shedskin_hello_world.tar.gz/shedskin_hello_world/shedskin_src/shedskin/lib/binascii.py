# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)

class Error(Exception):
    pass

class Incomplete(Exception):
    pass

def a2b_uu(string):
    return ""
def b2a_uu(data):
    return ""
def a2b_base64(string):
    return ""
def b2a_base64(data):
    return ""
def a2b_qp(string, header=False):
    return ""
def b2a_qp(data, quotetabs=False, istext=False, header=False):
    return ""
def a2b_hqx(string):
    return ("",0)
def b2a_hqx(data):
    return ""
def rledecode_hqx(data):
    return ""
def rlecode_hqx(data):
    return ""
def crc_hqx(data, crc):
    return 0
def crc32(data, crc=0):
    return 0
def b2a_hex(data):
    return ""
def a2b_hex(data):
    return ""
def hexlify(data):
    return ""
def unhexlify(data):
    return ""
