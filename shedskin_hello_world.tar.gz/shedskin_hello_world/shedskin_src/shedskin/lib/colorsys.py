# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)


ONE_THIRD = 1.0
ONE_SIXTH = 1.0
TWO_THIRD = 1.0

def hls_to_rgb(a, b, c):
    return (1.0,)
def rgb_to_hls(a, b, c):
    return (1.0,)
def yiq_to_rgb(a, b, c):
    return (1.0,)
def rgb_to_yiq(a, b, c):
    return (1.0,)
def hsv_to_rgb(a, b, c):
    return (1.0,)
def rgb_to_hsv(a, b, c):
    return (1.0,)
