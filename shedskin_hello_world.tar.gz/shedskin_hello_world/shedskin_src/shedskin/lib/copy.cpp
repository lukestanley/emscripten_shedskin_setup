/* Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE) */

#include "copy.hpp"

namespace __copy__ {

void __init() {

}


}
