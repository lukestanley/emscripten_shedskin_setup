# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)


import re, os, os.path

def fnmatch(name, pat):
    return True

def filter(names, pat):
    return ['']

def fnmatchcase(name, pat):
    return True

def translate(pat):
    return ''

def init():
    pass
