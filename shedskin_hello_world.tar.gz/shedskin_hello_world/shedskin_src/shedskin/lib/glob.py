# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)

import os, os.path, fnmatch, re

def iglob(s):
    return __iter('')

def glob(s):
    return ['']

def has_magic(s):
    return True
