/* Copyright (c) 2009 Jérémie Roquet <arkanosis@gmail.com>; License Expat (See LICENSE) */

#include "heapq.hpp"

namespace __heapq__ {

void __init() {

}


}
