/* Copyright (c) 2009 Jérémie Roquet <arkanosis@gmail.com>; License Expat (See LICENSE) */

#include "itertools.hpp"

namespace __itertools__ {

void __init() {

}


}
