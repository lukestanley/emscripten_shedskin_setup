# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)
def select(rFDs, wFDs, xFDs, timeout=-1.0):
    return ([1],)
