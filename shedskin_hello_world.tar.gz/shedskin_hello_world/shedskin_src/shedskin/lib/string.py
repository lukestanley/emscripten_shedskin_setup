# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)


ascii_letters = letters = ascii_lowercase = lowercase = ascii_uppercase = uppercase = whitespace = ''
printable = punctuation = ''

digits = hexdigits = octdigits = ''

def join(a, b=''):
    return ''
def joinfields(a, b=''):
    return ''

def find(s, sub, start=0, end=0):
    return 1
def rfind(s, sub, start=0, end=0):
    return 1
def index(s, sub, start=0, end=0):
    return 1
def rindex(s, sub, start=0, end=0):
    return 1

def rsplit(s, sep='', c=-1):
    return ['']

def split(s, sep='', c=-1):
    return ['']
def splitfields(s, sep='', c=-1):
    return ['']

def replace(s, a, b, c=-1):
    return ''

def translate(s, table, delchars=''):
    return ''

def count(s, sub, start=0, end=0):
    return 1
def expandtabs(s, width=8):
    return ''
def lower(s):
    return ''
def upper(s):
    return ''
def zfill(s, width):
    return ''

def strip(s, chars=''):
    return ''
def lstrip(s, chars=''):
    return ''
def rstrip(s, chars=''):
    return ''

def ljust(s, width, chars=''):
    return ''
def rjust(s, width, chars=''):
    return ''

def maketrans(frm, to):
    return ''

def capitalize(s):
    return ''
def capwords(s, sep=''):
    return ''

def swapcase(s):
    return ''

def center(s, w, fill=''):
    return ''

def atoi(s, base=10):
    return 1
def atol(s, base=10):
    return 1
def atof(s):
    return 1.0

