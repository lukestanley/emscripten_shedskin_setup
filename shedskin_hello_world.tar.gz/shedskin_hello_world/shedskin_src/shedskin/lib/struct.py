# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)

class error(Exception):
    pass

def pack(fmt, *vals):
    return ''

def unpack(fmt, s):
    pass

def calcsize(fmt):
    return 1
