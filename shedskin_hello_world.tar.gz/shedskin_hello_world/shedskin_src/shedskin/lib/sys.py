# Copyright 2005-2011 Mark Dufour and contributors; License Expat (See LICENSE)


argv = ['']

stdin, stdout, stderr = file('stdin'), file('stdout'), file('stderr')

version = ''
version_info = (0,)
copyright = ''
platform = ''
byteorder = ''
hexversion = 0
maxint = 0
maxsize = 0

def setrecursionlimit(limit):
    pass

def exit(code=0):
    pass
