#ifndef __HELLO_HPP
#define __HELLO_HPP

using namespace __shedskin__;
namespace __hello__ {

extern str *const_0;



extern str *__name__;



} // module namespace
#endif
