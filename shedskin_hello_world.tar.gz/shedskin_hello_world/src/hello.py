print "hello from shedskin in JS"
